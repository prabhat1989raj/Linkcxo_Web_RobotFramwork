*** Settings ***
Documentation    Low-level element actions for the User Profile page.
...              Mirrors Java ProfilePage.java 1:1 - one keyword per original method.
Library          SeleniumLibrary
Resource         ../Variables/Locators.robot
Resource         ../Variables/Config.robot

*** Keywords ***
# ---- Header ----
Click User Profile Icon
    Maximize Browser Window
    Capture Page Screenshot    before_profile_icon_click.png
    Wait Until Page Contains Element    xpath=//img    timeout=30s
    Wait Until Element Is Visible    ${USER_PROFILE_ICON}    timeout=30s
    Click Element    ${USER_PROFILE_ICON}

# ---- Banner / Photo ----
Update Profile Banner Image
    [Arguments]    ${file_path}
    Wait Until Element Is Visible    ${PROFILE_BANNER_IMAGE_INPUT}    timeout=${TIMEOUT}
    Choose File    ${PROFILE_BANNER_IMAGE_INPUT}    ${file_path}

Upload Profile Image
    [Arguments]    ${file_path}
    Wait Until Element Is Visible    ${PROFILE_IMAGE_INPUT}    timeout=${TIMEOUT}
    Choose File    ${PROFILE_IMAGE_INPUT}    ${file_path}

# ---- Profile Summary ----
Click Profile Summary Edit Icon
    Wait Until Element Is Visible    ${PROFILE_SUMMARY_EDIT_ICON}    timeout=${TIMEOUT}
    Click Element    ${PROFILE_SUMMARY_EDIT_ICON}

Update Profile Summary Text
    [Arguments]    ${summary_text}
    Wait Until Element Is Visible    ${PROFILE_SUMMARY_TEXTAREA}    timeout=${TIMEOUT}
    Clear Element Text    ${PROFILE_SUMMARY_TEXTAREA}
    Input Text    ${PROFILE_SUMMARY_TEXTAREA}    ${summary_text}

Click Save Button
    Wait Until Element Is Visible    ${SAVE_BUTTON}    timeout=${TIMEOUT}
    Click Element    ${SAVE_BUTTON}

Click Add Button
    Wait Until Element Is Visible    ${ADD_BUTTON}    timeout=${TIMEOUT}
    Click Element    ${ADD_BUTTON}

# ---- Profile Video ----
Click Add Video Icon
    Wait Until Element Is Visible    ${ADD_VIDEO_ICON_BTN}    timeout=${TIMEOUT}
    Click Element    ${ADD_VIDEO_ICON_BTN}

Upload Profile Video
    [Arguments]    ${file_path}
    Wait Until Element Is Visible    ${VIDEO_FILE_INPUT}    timeout=${TIMEOUT}
    Choose File    ${VIDEO_FILE_INPUT}    ${file_path}

# ---- Experience ----
Scroll To Experience Section
    Wait Until Element Is Visible    ${EXPERIENCE_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${EXPERIENCE_SECTION_HEADER}

Click Add Experience Button
    Wait Until Element Is Visible    ${EXPERIENCE_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${EXPERIENCE_ADD_BTN}

Enter Experience Designation
    [Arguments]    ${designation}
    Input Text    ${EXP_DESIGNATION_INPUT}    ${designation}

Select Employment Type Dropdown
    Click Element    ${DROPDOWN_TOGGLE}

Select Employment Type Full Time
    Click Element    ${EXP_EMP_TYPE_OPTION_FULLTIME}

Enter Experience Company Name
    [Arguments]    ${company_name}
    Input Text    ${EXP_COMPANY_NAME_INPUT}    ${company_name}

Enter Experience Location
    [Arguments]    ${location}
    Input Text    ${EXP_LOCATION_INPUT}    ${location}

Check Currently Working Checkbox
    Click Element    ${EXP_CURRENTLY_WORKING_CHECKBOX}

Open Experience Start Date Picker
    Click Element    ${EXP_START_DATE_INPUT}

Select Experience Start Date
    Click Element    ${EXP_DATE_PICKER_OPTION}

Enter Experience Summary
    [Arguments]    ${summary_text}
    Input Text    ${EXP_SUMMARY_TEXTAREA}    ${summary_text}

Enter Experience Skill
    [Arguments]    ${skill}
    Input Text    ${EXP_SKILL_INPUT}    ${skill}

# ---- Education ----
Scroll To Education Section
    Wait Until Element Is Visible    ${EDUCATION_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${EDUCATION_SECTION_HEADER}

Click Add Education Button
    Wait Until Element Is Visible    ${EDUCATION_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${EDUCATION_ADD_BTN}

Enter Education School Name
    [Arguments]    ${school_name}
    Input Text    ${EDU_SCHOOL_INPUT}    ${school_name}

Enter Education Degree
    [Arguments]    ${degree}
    Input Text    ${EDU_DEGREE_INPUT}    ${degree}

Enter Education Start Date
    [Arguments]    ${start_date}
    Input Text    ${EDU_START_DATE_INPUT}    ${start_date}

Enter Education End Date
    [Arguments]    ${end_date}
    Input Text    ${EDU_END_DATE_INPUT}    ${end_date}

Enter Education Field Of Study
    [Arguments]    ${field_of_study}
    Input Text    ${EDU_FIELD_OF_STUDY_INPUT}    ${field_of_study}

Enter Education Grade
    [Arguments]    ${grade}
    Input Text    ${EDU_GRADE_INPUT}    ${grade}

Enter Education Description
    [Arguments]    ${description}
    Input Text    ${EDU_DESCRIPTION_TEXTAREA}    ${description}

# ---- Skills ----
Scroll To Skills Section
    Wait Until Element Is Visible    ${SKILLS_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${SKILLS_SECTION_HEADER}

Click Add Skills Button
    Wait Until Element Is Visible    ${SKILLS_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${SKILLS_ADD_BTN}

Select Predefined Skills
    Click Element    ${SKILL_OPTION_PANDAS}
    Sleep    1s
    Click Element    ${SKILL_OPTION_PRODUCT_DESIGN}
    Sleep    1s
    Click Element    ${SKILL_OPTION_LANGCHAIN}
    Sleep    1s

# ---- Interest ----
Scroll To Interest Section
    Wait Until Element Is Visible    ${INTEREST_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${INTEREST_SECTION_HEADER}

Click Add Interest Button
    Wait Until Element Is Visible    ${INTEREST_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${INTEREST_ADD_BTN}

Select Predefined Interests
    Click Element    ${INTEREST_OPTION_BUSINESS}
    Sleep    1s
    Click Element    ${INTEREST_OPTION_FUNDRAISE}
    Sleep    1s
    Click Element    ${INTEREST_OPTION_CXO_NETWORK}
    Sleep    1s
    Click Element    ${INTEREST_OPTION_OTHERS}
    Sleep    1s

# ---- Industry ----
Scroll To Industry Section
    Wait Until Element Is Visible    ${INDUSTRY_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${INDUSTRY_SECTION_HEADER}

Click Add Industry Button
    Wait Until Element Is Visible    ${INDUSTRY_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${INDUSTRY_ADD_BTN}

Click Industry Search Input
    Click Element    ${INDUSTRY_SEARCH_INPUT}

Click Industry Checkbox Tick
    Click Element    ${INDUSTRY_CHECKBOX_TICK}

# ---- Awards & Certification ----
Scroll To Award Section
    Wait Until Element Is Visible    ${AWARD_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${AWARD_SECTION_HEADER}

Click Add Award Button
    Wait Until Element Is Visible    ${AWARD_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${AWARD_ADD_BTN}

Enter Award Title
    [Arguments]    ${title}
    Input Text    ${AWARD_TITLE_INPUT}    ${title}

Enter Award Certified By
    [Arguments]    ${certified_by}
    Input Text    ${AWARD_CERTIFIED_BY_INPUT}    ${certified_by}

Enter Award Issued On
    [Arguments]    ${issued_on}
    Input Text    ${AWARD_ISSUED_ON_INPUT}    ${issued_on}

Enter Award Description
    [Arguments]    ${description}
    Input Text    ${AWARD_DESCRIPTION_TEXTAREA}    ${description}

# ---- Publication ----
Scroll To Publication Section
    Wait Until Element Is Visible    ${PUBLICATION_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${PUBLICATION_SECTION_HEADER}

Click Add Publication Button
    Wait Until Element Is Visible    ${PUBLICATION_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${PUBLICATION_ADD_BTN}

Enter Publication Title
    [Arguments]    ${title}
    Input Text    ${PUB_TITLE_INPUT}    ${title}

Enter Publication Published By
    [Arguments]    ${published_by}
    Input Text    ${PUB_PUBLISHED_BY_INPUT}    ${published_by}

Enter Publication Co Author
    [Arguments]    ${co_author}
    Input Text    ${PUB_CO_AUTHOR_INPUT}    ${co_author}

Enter Publication Published On
    [Arguments]    ${published_on}
    Input Text    ${PUB_PUBLISHED_ON_INPUT}    ${published_on}

Enter Publication Description
    [Arguments]    ${description}
    Input Text    ${PUB_DESCRIPTION_TEXTAREA}    ${description}

# ---- Language ----
Scroll To Language Section
    Wait Until Element Is Visible    ${LANGUAGE_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${LANGUAGE_SECTION_HEADER}

Click Add Language Button
    Wait Until Element Is Visible    ${LANGUAGE_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${LANGUAGE_ADD_BTN}

Select Language Dropdown
    Click Element    ${LANGUAGE_DROPDOWN_TOGGLE}

Select Language English
    Click Element    ${LANGUAGE_OPTION_ENGLISH}

Check Language Reading
    Click Element    ${LANGUAGE_READING_CHECKBOX}

Check Language Writing
    Click Element    ${LANGUAGE_WRITING_CHECKBOX}

Check Language Speaking
    Click Element    ${LANGUAGE_SPEAKING_CHECKBOX}

# ---- Additional Information ----
Scroll To Additional Information Section
    Wait Until Element Is Visible    ${ADDITIONAL_INFO_SECTION_HEADER}    timeout=${TIMEOUT}
    Mouse Over    ${ADDITIONAL_INFO_SECTION_HEADER}

Click Add Additional Information Button
    Wait Until Element Is Visible    ${ADDITIONAL_INFO_ADD_BTN}    timeout=${TIMEOUT}
    Click Element    ${ADDITIONAL_INFO_ADD_BTN}

Enter Additional Email
    [Arguments]    ${email}
    Input Text    ${ADDITIONAL_EMAIL_INPUT}    ${email}

Select Preferred Industry
    Click Element    ${PREFERRED_INDUSTRY_DROPDOWN}
    Click Element    ${PREFERRED_INDUSTRY_OPTION_IT}

Select Preferred Location
    Click Element    ${PREFERRED_LOCATION_DROPDOWN}
    Click Element    ${PREFERRED_LOCATION_OPTION_PUNE}

Attach Resume
    [Arguments]    ${file_path}
    Choose File    ${ATTACH_RESUME_INPUT}    ${file_path}
