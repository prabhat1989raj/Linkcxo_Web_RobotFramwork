*** Settings ***
Library     SeleniumLibrary
Resource    ../Resources/Pages/LoginPage.robot
Resource    ../Resources/Keywords/ProfileKeywords.robot
Resource    ../Resources/Variables/Config.robot

Suite Setup       Open Browser And Maximize
Suite Teardown    Close Browser

*** Keywords ***
Open Browser And Maximize
    Open Browser    ${URL}    ${BROWSER}
    Maximize Browser Window

*** Test Cases ***
Update User Profile Details Successfully
    [Documentation]    Logs in and updates the user's profile details.
    [Tags]    regression    profile
    Login To Application
    Update Complete User Profile
